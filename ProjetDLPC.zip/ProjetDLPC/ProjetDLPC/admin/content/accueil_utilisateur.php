<?php
require ('src/php/utils/check_connection.php');

print "<br>Bonjour ".$_SESSION['utilisateur']."<br>";