INSERT INTO pcs (id_pc, nom_pc, photo_pc, prix_pc, type_pc) VALUES
(2, 'PC Razor', 'pc3.jpg', 699.99, 'PC GAMER PORTABLE'),
(1, 'Bureautique', 'pc2.jpg', 599.99, 'PC GAMER TOUR'),
(8, 'PC RGB', 'pc1.jpg', 1000.00, 'PC GAMER TOUR'),
(6, 'PC WaterCooling', 'pc5.jpg', 2000.00, 'ACCESSOIRES'),
(20, 'ECRAN MSI', 'MSI.jpg', 140.00, 'ACCESSOIRES'),
(19, 'ACER2', 'ACER.jpg', 2099.00, 'PC GAMER PORTABLE');


INSERT INTO admin (id_admin, nom_admin, login_admin, password_admin) VALUES
    (1, 'Loris', 'lolo', 'password');
