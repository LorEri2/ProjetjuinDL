<?php
$dsn = "pgsql:host=localhost;dbname=ProjetDLPC;port=5432";
$user = "anonyme";
$password = "anonyme";