<?php

class UtilisateurDAO
{
    private $_bd;
    private $_array = array();

    public function __construct($cnx)
    {
        $this->_bd = $cnx;
    }

    public function getUtilisateur($login_utilisateur, $password_utilisateur)
    {

        $query = "SELECT * FROM utilisateur WHERE login_utilisateur = :login AND password_utilisateur = :password";

        try {
            $this->_bd->beginTransaction();
            $resultset = $this->_bd->prepare($query);
            $resultset->bindValue(':login', $login_utilisateur);
            $resultset->bindValue(':password', $password_utilisateur);
            $resultset->execute();


            $user = $resultset->fetch(PDO::FETCH_ASSOC);

            $this->_bd->commit();

            if ($user) {
                return $user;
            } else {
                return null;
            }
        } catch (PDOException $e) {
            $this->_bd->rollback();
            print "Echec de la requête " . $e->getMessage();
        }
    }


}

