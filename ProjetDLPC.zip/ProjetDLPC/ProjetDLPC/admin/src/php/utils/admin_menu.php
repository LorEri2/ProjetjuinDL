
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<nav class="navbar navbar-expand-lg bg-dark navbar-dark px-3">
    <div class="container-fluid d-flex justify-content-between">


        <div class="d-flex">
            <a class="nav-link text-white me-3" href="index_.php?page=ajout_pc.php">Ajout PC</a>
            <a class="nav-link text-white me-3" href="index_.php?page=supp_pc.php">Suppression PC</a>
            <a class="nav-link text-white me-3" href="index_.php?page=update_pc.php">Update PC</a>
            <a class="nav-link text-white " href="index_.php?page=disconnect.php">Déconnexion</a>
        </div>
    </div>
</nav>
